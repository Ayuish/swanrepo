Kore python async/await examples.

Run:
```
	$ kodev run
```

Test:
```
	$ curl -k http://127.0.0.1:8888/queue
	$ curl -k http://127.0.0.1:8888/lock
	$ curl -k http://127.0.0.1:8888/proc
	$ curl -k http://127.0.0.1:8888/socket
```
