This example shows cookies API usage

* Simple key value cookie
* Complex cookie with RFC 6265 features
* Mix with cookie formatted in the header

Run:
```
	# kodev run
```
