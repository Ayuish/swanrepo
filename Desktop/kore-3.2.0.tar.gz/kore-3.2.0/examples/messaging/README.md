Kore message framework example

Run:
```
	# kodev run
```

Test:
```
	Perform a simple GET request against the root page.
	This should trigger the example app to send a message
	to the other workers which will display it.

	# curl -k https://127.0.0.1:8888
```
