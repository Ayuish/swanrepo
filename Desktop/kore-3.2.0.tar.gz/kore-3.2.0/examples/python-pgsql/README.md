Kore pgsql python module example.

This application requires kore to be built with PYTHON=1 PGSQL=1.

Run:
```
	$ kodev run
```

Test:
```
	$ curl -k https://127.0.0.1:8888
	$ curl -k https://127.0.0.1:8888/hello
	$ curl -k https://127.0.0.1:8888/slow
```
